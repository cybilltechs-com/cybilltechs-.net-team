#ifndef ETTERFILTER_VERSION_H
#define ETTERFILTER_VERSION_H

#define PROGRAM         "etterfilter"

#endif


/* EOF */

