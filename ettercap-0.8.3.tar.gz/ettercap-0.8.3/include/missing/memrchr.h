#ifndef EC_API_EXTERN
#error Move this header somewhere else
#endif

EC_API_EXTERN void *memrchr(const void *s, u_char c, size_t n);

/* EOF */

