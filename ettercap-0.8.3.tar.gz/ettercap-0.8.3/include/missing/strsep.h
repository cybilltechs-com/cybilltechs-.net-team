#ifndef EC_API_EXTERN
#error Move this header somewhere else
#endif

EC_API_EXTERN char * strsep(char **stringp, const char *delim);

/* EOF */

